<script lang="ts">
  import { onMount } from 'svelte';
  import Composer from './components/Composer.svelte';
  import MessageItem from './components/MessageItem.svelte';
  import ReportPanel from './components/ReportPanel.svelte';
  import SettingsModal from './components/SettingsModal.svelte';
  import { getOrCreateReport, db } from './db';
  import { formatReportAI, mergeReportsAI } from './reportAi';
  import { isWorkRelatedSmart } from './workDetect';
  import { aiGenerate } from './ai';

  let messages: { role: 'user' | 'assistant' | 'system'; content: string }[] = [];
  let settingsOpen = false;
  let showReport = true;
  let reportRef: any;

  let notifSound: HTMLAudioElement | null = null;
  const SOUND_SRC = '/notif.wav';

  function pingSound() {
    try {
      notifSound?.pause();
      notifSound!.currentTime = 0;
      notifSound?.play().catch(() => {});
    } catch {}
  }

  function desktopNotify(title: string, body: string) {
    if (document.hasFocus()) return;
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(title, { body: body.slice(0, 160), icon: '/icon.png' });
    }
  }

  onMount(() => {
    notifSound = new Audio(SOUND_SRC);
    notifSound.volume = 0.5;
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().catch(() => {});
    }
  });

  async function onSend(e: any) {
    const text = e.detail.text;
    messages = [...messages, { role: 'user', content: text }];

    let work = false;
    let reason = 'unknown';
    try {
      const c = await isWorkRelatedSmart(text);
      work = !!c.work;
      reason = c.reason || 'ai';
    } catch {}

    if (work) {
      try {
        const formatted = await formatReportAI(text, new Date().toISOString());
        const base = await getOrCreateReport();
        const merged = await mergeReportsAI(base.content, formatted, new Date().toISOString());
        await db.report.put({ id: 1, content: merged, updatedAt: Date.now() });
        messages = [...messages, { role: 'system', content: '📄 Laporan diperbarui (deteksi: ' + reason + '):\n' + merged }];
      } catch (err: any) {
        messages = [...messages, { role: 'assistant', content: '⚠️ Gagal update laporan: ' + (err?.message || 'ERR') }];
        pingSound();
        desktopNotify('Liora (Gagal Update)', String(err?.message || 'ERR'));
      }
    }

    try {
      const r = await getOrCreateReport();
      const sys = `Nama asisten: Liora. Gaya Gen Z, visioner, opini tegas. Bahasa: Indonesia.
KONTEKS KERJA:
${r.content}`;
      const out = await aiGenerate(sys, text);
      messages = [...messages, { role: 'assistant', content: out }];
      pingSound();
      desktopNotify('Liora', out);
    } catch (e: any) {
      messages = [...messages, { role: 'assistant', content: '⚠️ Gagal minta jawaban AI: ' + (e?.message || 'ERR') }];
      pingSound();
      desktopNotify('Liora (AI Error)', String(e?.message || 'ERR'));
    }

    reportRef?.refresh();
  }

  function toggleReport() {
    showReport = !showReport;
  }
</script>

<div class="flex h-screen bg-base-200 text-base-content">
  <!-- Sidebar Chat -->
  <aside class="flex flex-col w-full md:w-2/3 lg:w-3/4 border-r border-base-300 bg-base-100">
    <header class="navbar bg-base-200 border-b border-base-300 px-4">
      <div class="flex-1">
        <span class="btn btn-ghost normal-case text-lg font-semibold text-primary">Liora Chat</span>
      </div>
      <div class="flex items-center gap-2">
        <button class="btn btn-sm btn-ghost" on:click={() => (settingsOpen = true)}>⚙️</button>
        <button class="btn btn-sm btn-outline" on:click={toggleReport}>
          {showReport ? '➡️' : '⬅️'}
        </button>
      </div>
    </header>

    <main class="flex-1 overflow-y-auto p-4 space-y-3">
      {#each messages as m}
        <MessageItem role={m.role} content={m.content} />
      {/each}
    </main>

    <footer class="border-t border-base-300 bg-base-100 p-3">
      <Composer on:send={onSend}/>
    </footer>
  </aside>

  <!-- Report Panel -->
  <section
  class="transition-all duration-300 ease-in-out bg-base-100 shadow-inner overflow-auto w-full md:w-[400px]"
  class:hidden={!showReport}
>
  {#if showReport}
    <ReportPanel bind:this={reportRef}/>
  {/if}
</section>

</div>

<SettingsModal bind:open={settingsOpen}/>
