<script lang="ts">
  import { createEventDispatcher } from 'svelte';
  const dispatch = createEventDispatcher();
  let text = '';

  function send() {
    if (text.trim().length === 0) return;
    dispatch('send', { text });
    text = '';
  }
</script>

<div class="flex items-center gap-2">
  <button class="btn btn-ghost btn-circle text-xl">😊</button>
  <input
    bind:value={text}
    on:keydown={(e) => e.key === 'Enter' && send()}
    type="text"
    placeholder="Tulis pesan..."
    class="input input-bordered w-full rounded-full"
  />
  <button class="btn btn-primary btn-circle" on:click={send}>➤</button>
</div>
