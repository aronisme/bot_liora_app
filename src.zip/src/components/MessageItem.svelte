<script lang="ts">
  export let role: 'user' | 'assistant' | 'system' = 'user';
  export let content = '';
</script>

<div class="chat transition-all duration-300" class:chat-end={role === 'user'} class:chat-start={role !== 'user'}>
  {#if role === 'assistant'}
    <div class="chat-image avatar">
      <div class="w-10 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2">
        <img src="/icon.png" alt="Liora" />
      </div>
    </div>
  {:else if role === 'user'}
    <div class="chat-image avatar">
      <div class="w-10 rounded-full bg-primary text-white flex items-center justify-center font-bold shadow-md">U</div>
    </div>
  {:else}
    <div class="chat-image avatar">
      <div class="w-10 rounded-full bg-accent text-white flex items-center justify-center font-semibold">⚙️</div>
    </div>
  {/if}

  <div class="chat-header text-xs opacity-70 mb-1">
    {role === 'assistant' ? 'Liora' : role === 'user' ? 'Kamu' : 'System'}
  </div>

  <div
    class="chat-bubble text-sm whitespace-pre-wrap leading-relaxed"
    class:chat-bubble-primary={role === 'user'}
    class:chat-bubble-secondary={role === 'assistant'}
    class:chat-bubble-accent={role === 'system'}
  >
    {content}
  </div>
</div>
